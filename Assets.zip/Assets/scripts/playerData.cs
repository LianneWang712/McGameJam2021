﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class playerData
{
    public static bool hasKilled;

    public static bool HasKilled
    {
        get
        {
            return hasKilled;
        }
        set
        {
            hasKilled = value;
        }
    }
            
    
}
