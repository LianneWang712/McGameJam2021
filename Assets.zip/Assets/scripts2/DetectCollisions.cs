﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DetectCollisions : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    // when colliding with another gameObject, destroy both objects and 
    private void OnTriggerEnter(Collider other)
    {
       
        Destroy(gameObject);
        Destroy(other.gameObject);

        // check to see if enemy collided with player
        if (other.gameObject.CompareTag("Player"))
        {
            Debug.Log("Game Over");
        }
    }
}
